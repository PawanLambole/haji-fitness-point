export interface Admin {
  id: string;
  name: string;
  email: string;
  phone?: string;
  role: 'owner' | 'manager';
  photoURL?: string;
  createdAt: number;
}

export interface Member {
  id: string;
  assignmentNumber: string;
  fullName: string;
  phoneNumber: string;
  joiningDate: number;
  membershipStartDate: number;
  membershipEndDate: number;
  totalAmount: number;
  discountAmount: number;
  paymentMethod: {
    cash: number; // Number of times paid in cash
    upi: number; // Number of times paid via UPI
  };
  photoURL?: string;
  whatsappMessageSent: boolean;
  createdBy: string;
  createdAt: number;
  updatedAt: number;
}

export type ThemeMode = 'light' | 'dark';