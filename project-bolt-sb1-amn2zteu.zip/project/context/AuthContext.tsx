import React, { createContext, useState, useEffect, useContext } from 'react';
import { onAuthChanged, getDocument } from '../services/firebase';
import { Admin } from '../types';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface AuthContextType {
  currentUser: Admin | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  isOwner: boolean;
}

const AuthContext = createContext<AuthContextType>({
  currentUser: null,
  isLoading: true,
  isAuthenticated: false,
  isOwner: false
});

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<Admin | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthChanged(async (user) => {
      if (user) {
        // Get additional admin data from Firestore
        try {
          const adminDoc = await getDocument('admins', user.uid);
          if (adminDoc.exists()) {
            const adminData = adminDoc.data() as Admin;
            setCurrentUser({ id: user.uid, ...adminData });
          } else {
            // If admin document doesn't exist, user may have been created but not properly set up
            console.error('Admin document not found');
            setCurrentUser(null);
          }
        } catch (error) {
          console.error('Error fetching admin data:', error);
          setCurrentUser(null);
        }
      } else {
        setCurrentUser(null);
      }
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const value = {
    currentUser,
    isLoading,
    isAuthenticated: !!currentUser,
    isOwner: currentUser?.role === 'owner'
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => useContext(AuthContext);