import { initializeApp } from 'firebase/app';
import { 
  getAuth, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User as FirebaseUser
} from 'firebase/auth';
import { 
  getFirestore, 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  orderBy, 
  Timestamp, 
  serverTimestamp
} from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import { Platform } from 'react-native';

// TODO: Replace with your own Firebase config
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

// Auth functions
export const signIn = (email: string, password: string) => {
  return signInWithEmailAndPassword(auth, email, password);
};

export const createUser = (email: string, password: string) => {
  return createUserWithEmailAndPassword(auth, email, password);
};

export const signOut = () => {
  return firebaseSignOut(auth);
};

export const getCurrentUser = () => {
  return auth.currentUser;
};

export const onAuthChanged = (callback: (user: FirebaseUser | null) => void) => {
  return onAuthStateChanged(auth, callback);
};

// Firestore functions
export const getCollection = (collectionName: string) => {
  return collection(db, collectionName);
};

export const getDocumentRef = (collectionName: string, documentId: string) => {
  return doc(db, collectionName, documentId);
};

export const setDocument = (collectionName: string, documentId: string, data: any) => {
  return setDoc(doc(db, collectionName, documentId), {
    ...data,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  });
};

export const updateDocument = (collectionName: string, documentId: string, data: any) => {
  return updateDoc(doc(db, collectionName, documentId), {
    ...data,
    updatedAt: serverTimestamp()
  });
};

export const deleteDocument = (collectionName: string, documentId: string) => {
  return deleteDoc(doc(db, collectionName, documentId));
};

export const getDocument = (collectionName: string, documentId: string) => {
  return getDoc(doc(db, collectionName, documentId));
};

export const queryCollection = (collectionName: string, conditions: any[] = [], orderByField?: string, orderDirection?: 'asc' | 'desc') => {
  let q = collection(db, collectionName);
  
  if (conditions.length > 0) {
    q = query(q, ...conditions);
  }
  
  if (orderByField) {
    q = query(q, orderBy(orderByField, orderDirection || 'asc'));
  }
  
  return getDocs(q);
};

// WhatsApp integration
export const sendWhatsAppMessage = async (phoneNumber: string, name: string, startDate: string, endDate: string) => {
  // In a real implementation, you'd integrate with WhatsApp Business API or use a third-party service
  // For now, we'll just simulate sending a message and return success
  
  if (Platform.OS === 'web') {
    console.log(`Sending WhatsApp message to ${phoneNumber}: Hi ${name}, your gym membership has started from ${startDate} to ${endDate}. Thank you!`);
  }
  
  return { success: true };
};

export { 
  app, 
  auth, 
  db, 
  storage,
  where,
  orderBy,
  Timestamp
};