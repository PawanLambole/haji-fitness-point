import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useTheme } from '@/context/ThemeContext';
import { useAuth } from '@/context/AuthContext';
import { queryCollection, where, Timestamp } from '@/services/firebase';
import { Member } from '@/types';
import { Users, Calendar, DollarSign, Activity } from 'lucide-react-native';
import { useRouter } from 'expo-router';

export default function Dashboard() {
  const router = useRouter();
  const { colors } = useTheme();
  const { currentUser } = useAuth();
  const [stats, setStats] = useState({
    totalMembers: 0,
    activeMembers: 0,
    expiringThisWeek: 0,
    expiredMembers: 0,
    totalRevenue: 0,
  });
  const [loading, setLoading] = useState(true);
  const [recentMembers, setRecentMembers] = useState<Member[]>([]);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        
        // Get all members
        const membersSnapshot = await queryCollection('members', [], 'createdAt', 'desc');
        const members = membersSnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as Member[];
        
        // Calculate stats
        const now = new Date();
        const nextWeek = new Date();
        nextWeek.setDate(now.getDate() + 7);
        
        const activeMembers = members.filter(member => 
          new Date(member.membershipEndDate) >= now
        );
        
        const expiringThisWeek = members.filter(member => {
          const endDate = new Date(member.membershipEndDate);
          return endDate >= now && endDate <= nextWeek;
        });
        
        const expiredMembers = members.filter(member => 
          new Date(member.membershipEndDate) < now
        );
        
        const totalRevenue = members.reduce(
          (total, member) => total + (member.totalAmount - member.discountAmount),
          0
        );
        
        setStats({
          totalMembers: members.length,
          activeMembers: activeMembers.length,
          expiringThisWeek: expiringThisWeek.length,
          expiredMembers: expiredMembers.length,
          totalRevenue,
        });
        
        // Get recent members (last 5)
        setRecentMembers(members.slice(0, 5));
        
        setLoading(false);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
        setLoading(false);
      }
    };
    
    fetchDashboardData();
  }, []);

  if (loading) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.headerContainer}>
        <Text style={[styles.welcomeText, { color: colors.text }]}>
          Welcome back, {currentUser?.name || 'Admin'}
        </Text>
        <Text style={[styles.dateText, { color: colors.grayDark }]}>
          {new Date().toLocaleDateString('en-US', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })}
        </Text>
      </View>
      
      <View style={styles.statsContainer}>
        <TouchableOpacity 
          style={[styles.statCard, { backgroundColor: colors.card }]}
          onPress={() => router.push('/members')}
        >
          <View style={[styles.iconContainer, { backgroundColor: colors.primary + '20' }]}>
            <Users size={24} color={colors.primary} />
          </View>
          <Text style={[styles.statValue, { color: colors.text }]}>{stats.totalMembers}</Text>
          <Text style={[styles.statLabel, { color: colors.grayDark }]}>Total Members</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.statCard, { backgroundColor: colors.card }]}
          onPress={() => router.push('/members')}
        >
          <View style={[styles.iconContainer, { backgroundColor: colors.success + '20' }]}>
            <Activity size={24} color={colors.success} />
          </View>
          <Text style={[styles.statValue, { color: colors.text }]}>{stats.activeMembers}</Text>
          <Text style={[styles.statLabel, { color: colors.grayDark }]}>Active Members</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.statCard, { backgroundColor: colors.card }]}
          onPress={() => router.push('/members')}
        >
          <View style={[styles.iconContainer, { backgroundColor: colors.warning + '20' }]}>
            <Calendar size={24} color={colors.warning} />
          </View>
          <Text style={[styles.statValue, { color: colors.text }]}>{stats.expiringThisWeek}</Text>
          <Text style={[styles.statLabel, { color: colors.grayDark }]}>Expiring This Week</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.statCard, { backgroundColor: colors.card }]}
          onPress={() => router.push('/members')}
        >
          <View style={[styles.iconContainer, { backgroundColor: colors.primary + '20' }]}>
            <DollarSign size={24} color={colors.primary} />
          </View>
          <Text style={[styles.statValue, { color: colors.text }]}>₹{stats.totalRevenue}</Text>
          <Text style={[styles.statLabel, { color: colors.grayDark }]}>Total Revenue</Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.sectionContainer}>
        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Recently Added Members</Text>
          <TouchableOpacity onPress={() => router.push('/members')}>
            <Text style={[styles.sectionLink, { color: colors.primary }]}>View All</Text>
          </TouchableOpacity>
        </View>
        
        {recentMembers.length > 0 ? (
          <View style={[styles.membersListContainer, { backgroundColor: colors.card }]}>
            {recentMembers.map((member, index) => (
              <TouchableOpacity 
                key={member.id}
                style={[
                  styles.memberItem, 
                  index < recentMembers.length - 1 && { borderBottomWidth: 1, borderBottomColor: colors.border }
                ]}
                onPress={() => router.push(`/members/${member.id}`)}
              >
                <View style={styles.memberInfo}>
                  <Text style={[styles.memberName, { color: colors.text }]}>{member.fullName}</Text>
                  <Text style={[styles.memberDetail, { color: colors.grayDark }]}>
                    #{member.assignmentNumber} • {new Date(member.joiningDate).toLocaleDateString()}
                  </Text>
                </View>
                <View>
                  <Text style={[styles.memberStatus, { 
                    color: new Date(member.membershipEndDate) >= new Date() ? colors.success : colors.error 
                  }]}>
                    {new Date(member.membershipEndDate) >= new Date() ? 'Active' : 'Expired'}
                  </Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        ) : (
          <View style={[styles.emptyContainer, { backgroundColor: colors.card }]}>
            <Text style={[styles.emptyText, { color: colors.grayDark }]}>No members added yet</Text>
          </View>
        )}
      </View>
      
      <View style={styles.sectionContainer}>
        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Expiring Memberships</Text>
          <TouchableOpacity onPress={() => router.push('/members')}>
            <Text style={[styles.sectionLink, { color: colors.primary }]}>View All</Text>
          </TouchableOpacity>
        </View>
        
        {stats.expiringThisWeek > 0 ? (
          <View style={[styles.membersListContainer, { backgroundColor: colors.card }]}>
            {/* This would be populated with expiring members */}
            <Text style={[styles.tempText, { color: colors.text }]}>
              {stats.expiringThisWeek} memberships expiring this week
            </Text>
          </View>
        ) : (
          <View style={[styles.emptyContainer, { backgroundColor: colors.card }]}>
            <Text style={[styles.emptyText, { color: colors.grayDark }]}>No memberships expiring this week</Text>
          </View>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  headerContainer: {
    marginBottom: 24,
  },
  welcomeText: {
    fontSize: 24,
    fontFamily: 'Montserrat-Bold',
    marginBottom: 4,
  },
  dateText: {
    fontSize: 14,
    fontFamily: 'Montserrat-Regular',
  },
  statsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  statCard: {
    width: '48%',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  statValue: {
    fontSize: 24,
    fontFamily: 'Montserrat-Bold',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 14,
    fontFamily: 'Montserrat-Regular',
  },
  sectionContainer: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Montserrat-Bold',
  },
  sectionLink: {
    fontSize: 14,
    fontFamily: 'Montserrat-Medium',
  },
  membersListContainer: {
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  memberItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
  },
  memberInfo: {
    flex: 1,
  },
  memberName: {
    fontSize: 16,
    fontFamily: 'Montserrat-Medium',
    marginBottom: 4,
  },
  memberDetail: {
    fontSize: 14,
    fontFamily: 'Montserrat-Regular',
  },
  memberStatus: {
    fontSize: 14,
    fontFamily: 'Montserrat-Medium',
  },
  emptyContainer: {
    padding: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyText: {
    fontSize: 14,
    fontFamily: 'Montserrat-Regular',
    textAlign: 'center',
  },
  tempText: {
    padding: 16,
    fontSize: 14,
    fontFamily: 'Montserrat-Regular',
    textAlign: 'center',
  },
});