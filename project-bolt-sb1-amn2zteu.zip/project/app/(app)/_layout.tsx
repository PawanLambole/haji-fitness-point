import React from 'react';
import { Tabs } from 'expo-router';
import { useTheme } from '@/context/ThemeContext';
import { useAuth } from '@/context/AuthContext';
import { Users, UserPlus, Chrome as Home, Settings } from 'lucide-react-native';
import { Text, View, StyleSheet, TouchableOpacity } from 'react-native';

export default function AppLayout() {
  const { colors } = useTheme();
  const { isOwner } = useAuth();

  return (
    <Tabs
      screenOptions={{
        tabBarStyle: {
          backgroundColor: colors.card,
          borderTopColor: colors.border,
          height: 60,
          paddingBottom: 10,
        },
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.inactive,
        tabBarLabelStyle: styles.tabBarLabel,
        headerStyle: {
          backgroundColor: colors.card,
          borderBottomColor: colors.border,
          borderBottomWidth: 1,
          elevation: 0,
          shadowOpacity: 0,
        },
        headerTitleStyle: {
          fontFamily: 'Montserrat-Bold',
          color: colors.text,
        },
        headerTintColor: colors.text,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Dashboard',
          tabBarLabel: 'Dashboard',
          tabBarIcon: ({ color, size }) => <Home size={size} color={color} />,
        }}
      />
      <Tabs.Screen
        name="members/index"
        options={{
          title: 'Members',
          tabBarLabel: 'Members',
          tabBarIcon: ({ color, size }) => <Users size={size} color={color} />,
        }}
      />
      {isOwner && (
        <Tabs.Screen
          name="admins/index"
          options={{
            title: 'Admins',
            tabBarLabel: 'Admins',
            tabBarIcon: ({ color, size }) => <UserPlus size={size} color={color} />,
          }}
        />
      )}
      <Tabs.Screen
        name="settings"
        options={{
          title: 'Settings',
          tabBarLabel: 'Settings',
          tabBarIcon: ({ color, size }) => <Settings size={size} color={color} />,
        }}
      />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  tabBarLabel: {
    fontFamily: 'Montserrat-Medium',
    fontSize: 12,
  },
});