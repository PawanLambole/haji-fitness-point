import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  Alert, 
  ActivityIndicator,
  TextInput,
  ScrollView
} from 'react-native';
import { useTheme } from '@/context/ThemeContext';
import { useAuth } from '@/context/AuthContext';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { getDocument, updateDocument, deleteDocument } from '@/services/firebase';
import { Admin } from '@/types';
import { CreditCard as Edit, Trash2, ChevronLeft, User, Shield } from 'lucide-react-native';

export default function AdminDetailsScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { colors } = useTheme();
  const { currentUser, isOwner } = useAuth();
  const router = useRouter();
  
  const [admin, setAdmin] = useState<Admin | null>(null);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  
  // Edit form states
  const [editedAdmin, setEditedAdmin] = useState<Partial<Admin>>({});
  
  useEffect(() => {
    if (!isOwner) {
      Alert.alert('Access Denied', 'Only owner admins can access this page');
      router.replace('/(app)/');
      return;
    }
    
    if (id) {
      fetchAdminDetails();
    }
  }, [id, isOwner]);
  
  const fetchAdminDetails = async () => {
    try {
      setLoading(true);
      const adminDoc = await getDocument('admins', id);
      if (adminDoc.exists()) {
        const adminData = { id, ...adminDoc.data() } as Admin;
        setAdmin(adminData);
        setEditedAdmin(adminData);
      } else {
        Alert.alert('Error', 'Admin not found');
        router.back();
      }
    } catch (error) {
      console.error('Error fetching admin details:', error);
      Alert.alert('Error', 'Failed to load admin details');
    } finally {
      setLoading(false);
    }
  };
  
  const handleEdit = () => {
    setIsEditing(true);
  };
  
  const handleCancel = () => {
    setEditedAdmin(admin || {});
    setIsEditing(false);
  };
  
  const handleSave = async () => {
    if (!admin || !editedAdmin) return;
    
    try {
      setIsSaving(true);
      
      await updateDocument('admins', admin.id, {
        name: editedAdmin.name,
        role: editedAdmin.role,
        updatedAt: Date.now()
      });
      
      // Refresh admin data
      fetchAdminDetails();
      setIsEditing(false);
      Alert.alert('Success', 'Admin updated successfully');
    } catch (error) {
      console.error('Error updating admin:', error);
      Alert.alert('Error', 'Failed to update admin');
    } finally {
      setIsSaving(false);
    }
  };
  
  const handleDelete = () => {
    if (admin?.id === currentUser?.id) {
      Alert.alert('Error', 'You cannot delete your own account');
      return;
    }
    
    Alert.alert(
      'Delete Admin',
      'Are you sure you want to delete this admin? This action cannot be undone.',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: confirmDelete,
        },
      ]
    );
  };
  
  const confirmDelete = async () => {
    if (!admin) return;
    
    try {
      setIsDeleting(true);
      await deleteDocument('admins', admin.id);
      Alert.alert('Success', 'Admin deleted successfully');
      router.back();
    } catch (error) {
      console.error('Error deleting admin:', error);
      Alert.alert('Error', 'Failed to delete admin');
      setIsDeleting(false);
    }
  };
  
  if (loading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: colors.background }]}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }
  
  if (!admin) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: colors.background }]}>
        <Text style={[styles.errorText, { color: colors.error }]}>
          Admin not found
        </Text>
        <TouchableOpacity
          style={[styles.backButton, { backgroundColor: colors.primary }]}
          onPress={() => router.back()}
        >
          <Text style={styles.backButtonText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }
  
  const isCurrentUser = admin.id === currentUser?.id;
  
  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { backgroundColor: colors.card }]}>
        <TouchableOpacity
          style={styles.backButtonContainer}
          onPress={() => router.back()}
        >
          <ChevronLeft size={24} color={colors.text} />
        </TouchableOpacity>
        
        <View style={styles.headerActions}>
          {!isEditing ? (
            <>
              <TouchableOpacity
                style={[styles.actionButton, { backgroundColor: colors.primary + '20' }]}
                onPress={handleEdit}
              >
                <Edit size={20} color={colors.primary} />
              </TouchableOpacity>
              
              {!isCurrentUser && (
                <TouchableOpacity
                  style={[styles.actionButton, { backgroundColor: colors.error + '20' }]}
                  onPress={handleDelete}
                  disabled={isDeleting}
                >
                  {isDeleting ? (
                    <ActivityIndicator size="small" color={colors.error} />
                  ) : (
                    <Trash2 size={20} color={colors.error} />
                  )}
                </TouchableOpacity>
              )}
            </>
          ) : (
            <>
              <TouchableOpacity
                style={[styles.textButton, { backgroundColor: colors.error + '20' }]}
                onPress={handleCancel}
              >
                <Text style={[styles.textButtonText, { color: colors.error }]}>Cancel</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[styles.textButton, { backgroundColor: colors.primary }]}
                onPress={handleSave}
                disabled={isSaving}
              >
                {isSaving ? (
                  <ActivityIndicator size="small" color="#000000" />
                ) : (
                  <Text style={styles.saveButtonText}>Save</Text>
                )}
              </TouchableOpacity>
            </>
          )}
        </View>
      </View>
      
      <ScrollView style={styles.content}>
        <View style={styles.profileSection}>
          <View style={[styles.photoContainer, { backgroundColor: colors.primary }]}>
            <Text style={styles.photoText}>
              {admin.name.charAt(0)}
            </Text>
          </View>
          
          {isEditing ? (
            <TextInput
              style={[styles.nameInput, { color: colors.text, borderColor: colors.border, backgroundColor: colors.card }]}
              value={editedAdmin.name}
              onChangeText={(text) => setEditedAdmin({ ...editedAdmin, name: text })}
            />
          ) : (
            <Text style={[styles.adminName, { color: colors.text }]}>
              {admin.name} {isCurrentUser ? '(You)' : ''}
            </Text>
          )}
          
          <View style={[
            styles.roleBadge,
            { backgroundColor: admin.role === 'owner' ? colors.primary + '20' : colors.grayLight + '50' }
          ]}>
            <Text style={[
              styles.roleText,
              { color: admin.role === 'owner' ? colors.primary : colors.grayDark }
            ]}>
              {admin.role === 'owner' ? 'Owner Admin' : 'Manager Admin'}
            </Text>
          </View>
        </View>
        
        <View style={styles.detailsSection}>
          <View style={[styles.detailCard, { backgroundColor: colors.card }]}>
            <Text style={[styles.detailCardTitle, { color: colors.text }]}>Admin Information</Text>
            
            <View style={styles.detailRow}>
              <View style={styles.detailLabelContainer}>
                <Text style={[styles.detailLabel, { color: colors.grayDark }]}>Email:</Text>
              </View>
              <Text style={[styles.detailValue, { color: colors.text }]}>{admin.email}</Text>
            </View>
            
            <View style={styles.detailRow}>
              <View style={styles.detailLabelContainer}>
                <Text style={[styles.detailLabel, { color: colors.grayDark }]}>Role:</Text>
              </View>
              
              {isEditing && !isCurrentUser ? (
                <View style={styles.roleSelectContainer}>
                  <TouchableOpacity
                    style={[
                      styles.roleSelectButton,
                      { 
                        backgroundColor: editedAdmin.role === 'manager' ? colors.primary : colors.background,
                        borderColor: colors.border
                      }
                    ]}
                    onPress={() => setEditedAdmin({ ...editedAdmin, role: 'manager' })}
                  >
                    <Text style={[
                      styles.roleSelectText,
                      { color: editedAdmin.role === 'manager' ? '#000000' : colors.text }
                    ]}>
                      Manager
                    </Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity
                    style={[
                      styles.roleSelectButton,
                      { 
                        backgroundColor: editedAdmin.role === 'owner' ? colors.primary : colors.background,
                        borderColor: colors.border
                      }
                    ]}
                    onPress={() => setEditedAdmin({ ...editedAdmin, role: 'owner' })}
                  >
                    <Text style={[
                      styles.roleSelectText,
                      { color: editedAdmin.role === 'owner' ? '#000000' : colors.text }
                    ]}>
                      Owner
                    </Text>
                  </TouchableOpacity>
                </View>
              ) : (
                <Text style={[styles.detailValue, { color: colors.text }]}>
                  {admin.role === 'owner' ? 'Owner Admin' : 'Manager Admin'}
                </Text>
              )}
            </View>
            
            <View style={styles.detailRow}>
              <View style={styles.detailLabelContainer}>
                <Text style={[styles.detailLabel, { color: colors.grayDark }]}>Created At:</Text>
              </View>
              <Text style={[styles.detailValue, { color: colors.text }]}>
                {new Date(admin.createdAt).toLocaleDateString()}
              </Text>
            </View>
          </View>
          
          <View style={[styles.detailCard, { backgroundColor: colors.card }]}>
            <Text style={[styles.detailCardTitle, { color: colors.text }]}>Permissions</Text>
            
            <View style={styles.permissionItem}>
              <User size={20} color={admin.role === 'owner' || admin.role === 'manager' ? colors.success : colors.grayLight} />
              <View style={styles.permissionTextContainer}>
                <Text style={[styles.permissionTitle, { color: colors.text }]}>
                  Member Management
                </Text>
                <Text style={[styles.permissionDescription, { color: colors.grayDark }]}>
                  Create, view, edit, and delete gym members
                </Text>
              </View>
            </View>
            
            <View style={styles.permissionItem}>
              <Shield size={20} color={admin.role === 'owner' ? colors.success : colors.grayLight} />
              <View style={styles.permissionTextContainer}>
                <Text style={[styles.permissionTitle, { color: colors.text }]}>
                  Admin Management
                </Text>
                <Text style={[styles.permissionDescription, { color: colors.grayDark }]}>
                  Create, view, edit, and delete gym administrators
                </Text>
              </View>
            </View>
            
            {isEditing && isCurrentUser && admin.role === 'owner' && editedAdmin.role === 'manager' && (
              <View style={[styles.warningContainer, { backgroundColor: colors.warning + '20' }]}>
                <Text style={[styles.warningText, { color: colors.warning }]}>
                  Warning: Changing your role to Manager will remove your ability to manage admins, including changing your role back to Owner.
                </Text>
              </View>
            )}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#e1e1e1',
  },
  backButtonContainer: {
    padding: 8,
  },
  headerActions: {
    flexDirection: 'row',
  },
  actionButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
  textButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    marginLeft: 8,
  },
  textButtonText: {
    fontFamily: 'Montserrat-Medium',
    fontSize: 14,
  },
  saveButtonText: {
    fontFamily: 'Montserrat-Medium',
    fontSize: 14,
    color: '#000000',
  },
  content: {
    flex: 1,
  },
  profileSection: {
    alignItems: 'center',
    paddingVertical: 24,
  },
  photoContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  photoText: {
    fontSize: 40,
    fontFamily: 'Montserrat-Bold',
    color: '#000000',
  },
  adminName: {
    fontSize: 24,
    fontFamily: 'Montserrat-Bold',
    marginBottom: 8,
  },
  nameInput: {
    fontSize: 24,
    fontFamily: 'Montserrat-Bold',
    marginBottom: 8,
    padding: 8,
    borderWidth: 1,
    borderRadius: 8,
    textAlign: 'center',
    minWidth: 200,
  },
  roleBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  roleText: {
    fontSize: 14,
    fontFamily: 'Montserrat-Medium',
  },
  detailsSection: {
    padding: 16,
  },
  detailCard: {
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  detailCardTitle: {
    fontSize: 18,
    fontFamily: 'Montserrat-Bold',
    marginBottom: 16,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  detailLabelContainer: {
    flex: 1,
  },
  detailLabel: {
    fontSize: 14,
    fontFamily: 'Montserrat-Regular',
  },
  detailValue: {
    fontSize: 16,
    fontFamily: 'Montserrat-Medium',
    flex: 1,
    textAlign: 'right',
  },
  roleSelectContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  roleSelectButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
    marginLeft: 8,
  },
  roleSelectText: {
    fontSize: 14,
    fontFamily: 'Montserrat-Medium',
  },
  permissionItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  permissionTextContainer: {
    flex: 1,
    marginLeft: 12,
  },
  permissionTitle: {
    fontSize: 16,
    fontFamily: 'Montserrat-Medium',
    marginBottom: 4,
  },
  permissionDescription: {
    fontSize: 14,
    fontFamily: 'Montserrat-Regular',
  },
  warningContainer: {
    padding: 12,
    borderRadius: 8,
    marginTop: 16,
  },
  warningText: {
    fontSize: 14,
    fontFamily: 'Montserrat-Medium',
  },
  errorText: {
    fontSize: 18,
    fontFamily: 'Montserrat-Medium',
    marginBottom: 16,
  },
  backButton: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  backButtonText: {
    fontSize: 16,
    fontFamily: 'Montserrat-Medium',
    color: '#000000',
  },
});