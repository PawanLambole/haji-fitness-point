import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity, 
  ActivityIndicator,
  Alert
} from 'react-native';
import { useTheme } from '@/context/ThemeContext';
import { useRouter } from 'expo-router';
import { useAuth } from '@/context/AuthContext';
import { queryCollection, orderBy } from '@/services/firebase';
import { Admin } from '@/types';
import { Plus, UserX } from 'lucide-react-native';

export default function AdminsScreen() {
  const { colors } = useTheme();
  const router = useRouter();
  const { currentUser, isOwner } = useAuth();
  const [admins, setAdmins] = useState<Admin[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isOwner) {
      Alert.alert('Access Denied', 'Only owner admins can access this page');
      router.replace('/(app)/');
      return;
    }
    
    fetchAdmins();
  }, [isOwner]);

  const fetchAdmins = async () => {
    try {
      setLoading(true);
      const adminsSnapshot = await queryCollection('admins', [], 'createdAt', 'desc');
      const adminsData = adminsSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Admin[];
      
      setAdmins(adminsData);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching admins:', error);
      setLoading(false);
    }
  };

  const handleAddAdmin = () => {
    router.push('/admins/add');
  };

  const renderAdminItem = ({ item }: { item: Admin }) => {
    const isCurrentUser = item.id === currentUser?.id;
    
    return (
      <TouchableOpacity
        style={[styles.adminCard, { backgroundColor: colors.card }]}
        onPress={() => router.push(`/admins/${item.id}`)}
      >
        <View style={styles.adminHeader}>
          <View style={styles.adminInfo}>
            <View style={[styles.adminInitials, { backgroundColor: colors.primary }]}>
              <Text style={styles.initialsText}>{item.name.charAt(0)}</Text>
            </View>
            <View>
              <Text style={[styles.adminName, { color: colors.text }]}>
                {item.name} {isCurrentUser ? '(You)' : ''}
              </Text>
              <Text style={[styles.adminEmail, { color: colors.grayDark }]}>{item.email}</Text>
            </View>
          </View>
          <View style={[
            styles.roleBadge, 
            { backgroundColor: item.role === 'owner' ? colors.primary + '20' : colors.grayLight + '50' }
          ]}>
            <Text style={[
              styles.roleText, 
              { color: item.role === 'owner' ? colors.primary : colors.grayDark }
            ]}>
              {item.role === 'owner' ? 'Owner' : 'Manager'}
            </Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <Text style={[styles.headerTitle, { color: colors.text }]}>Admins</Text>
        <TouchableOpacity
          style={[styles.addButton, { backgroundColor: colors.primary }]}
          onPress={handleAddAdmin}
        >
          <Plus size={24} color="#000000" />
        </TouchableOpacity>
      </View>
      
      {loading ? (
        <View style={styles.loaderContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : admins.length > 0 ? (
        <FlatList
          data={admins}
          renderItem={renderAdminItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
        />
      ) : (
        <View style={styles.emptyContainer}>
          <UserX size={64} color={colors.grayLight} />
          <Text style={[styles.emptyTitle, { color: colors.text }]}>No admins found</Text>
          <Text style={[styles.emptySubtitle, { color: colors.grayDark }]}>
            Add your first admin to get started
          </Text>
          <TouchableOpacity
            style={[styles.emptyButton, { backgroundColor: colors.primary }]}
            onPress={handleAddAdmin}
          >
            <Text style={styles.emptyButtonText}>Add Admin</Text>
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 28,
    fontFamily: 'Montserrat-Bold',
  },
  addButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  listContainer: {
    paddingBottom: 16,
  },
  adminCard: {
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  adminHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  adminInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  adminInitials: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  initialsText: {
    color: '#000000',
    fontSize: 20,
    fontFamily: 'Montserrat-Bold',
  },
  adminName: {
    fontSize: 16,
    fontFamily: 'Montserrat-Bold',
    marginBottom: 4,
  },
  adminEmail: {
    fontSize: 14,
    fontFamily: 'Montserrat-Regular',
  },
  roleBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  roleText: {
    fontSize: 12,
    fontFamily: 'Montserrat-Medium',
  },
  loaderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  emptyTitle: {
    fontSize: 18,
    fontFamily: 'Montserrat-Bold',
    marginTop: 16,
  },
  emptySubtitle: {
    fontSize: 14,
    fontFamily: 'Montserrat-Regular',
    textAlign: 'center',
    marginTop: 8,
  },
  emptyButton: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
    marginTop: 16,
  },
  emptyButtonText: {
    fontSize: 14,
    fontFamily: 'Montserrat-Bold',
    color: '#000000',
  },
});