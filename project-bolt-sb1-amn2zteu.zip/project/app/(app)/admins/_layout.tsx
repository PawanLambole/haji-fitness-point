import { Stack } from 'expo-router';

export default function AdminsLayout() {
  return (
    <Stack>
      <Stack.Screen 
        name="index" 
        options={{ 
          headerShown: false,
        }} 
      />
      <Stack.Screen 
        name="add" 
        options={{ 
          title: 'Add New Admin',
          presentation: 'modal'
        }} 
      />
      <Stack.Screen 
        name="[id]" 
        options={{ 
          title: 'Admin Details',
        }} 
      />
    </Stack>
  );
}