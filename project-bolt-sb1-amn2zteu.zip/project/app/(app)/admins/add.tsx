import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TextInput, 
  TouchableOpacity, 
  ScrollView, 
  KeyboardAvoidingView, 
  Platform,
  Alert,
  ActivityIndicator
} from 'react-native';
import { useTheme } from '@/context/ThemeContext';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from 'expo-router';
import { createUser, setDocument } from '@/services/firebase';
import { Eye, EyeOff, Mail, User, Shield } from 'lucide-react-native';

export default function AddAdminScreen() {
  const { colors } = useTheme();
  const { currentUser, isOwner } = useAuth();
  const router = useRouter();
  
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [role, setRole] = useState<'owner' | 'manager'>('manager');
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  React.useEffect(() => {
    if (!isOwner) {
      Alert.alert('Access Denied', 'Only owner admins can access this page');
      router.replace('/(app)/');
    }
  }, [isOwner]);
  
  const validateForm = () => {
    if (!name) {
      Alert.alert('Error', 'Please enter admin name');
      return false;
    }
    
    if (!email) {
      Alert.alert('Error', 'Please enter email');
      return false;
    }
    
    if (!password) {
      Alert.alert('Error', 'Please enter password');
      return false;
    }
    
    if (password.length < 6) {
      Alert.alert('Error', 'Password must be at least 6 characters');
      return false;
    }
    
    if (password !== confirmPassword) {
      Alert.alert('Error', 'Passwords do not match');
      return false;
    }
    
    return true;
  };
  
  const handleSubmit = async () => {
    if (!validateForm()) return;
    if (!currentUser || !isOwner) {
      Alert.alert('Error', 'You must be an owner admin to add administrators');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Create user in Firebase Auth
      const userCredential = await createUser(email, password);
      const userId = userCredential.user.uid;
      
      // Add admin data to Firestore
      await setDocument('admins', userId, {
        name,
        email,
        role,
        createdBy: currentUser.id,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });
      
      Alert.alert(
        'Success',
        'Admin added successfully',
        [{ text: 'OK', onPress: () => router.back() }]
      );
    } catch (error: any) {
      console.error('Error adding admin:', error);
      
      let errorMessage = 'Failed to add admin';
      if (error.code === 'auth/email-already-in-use') {
        errorMessage = 'Email is already in use';
      } else if (error.code === 'auth/invalid-email') {
        errorMessage = 'Invalid email format';
      }
      
      Alert.alert('Error', errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1 }}
    >
      <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={styles.header}>
          <Text style={[styles.headerTitle, { color: colors.text }]}>Add New Admin</Text>
        </View>
        
        <View style={styles.formSection}>
          <View style={[styles.inputContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <User size={20} color={colors.gray} style={styles.inputIcon} />
            <TextInput
              style={[styles.input, { color: colors.text }]}
              placeholder="Full Name"
              placeholderTextColor={colors.gray}
              value={name}
              onChangeText={setName}
            />
          </View>
          
          <View style={[styles.inputContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Mail size={20} color={colors.gray} style={styles.inputIcon} />
            <TextInput
              style={[styles.input, { color: colors.text }]}
              placeholder="Email"
              placeholderTextColor={colors.gray}
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
            />
          </View>
          
          <View style={[styles.inputContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Shield size={20} color={colors.gray} style={styles.inputIcon} />
            <TextInput
              style={[styles.input, { color: colors.text }]}
              placeholder="Password"
              placeholderTextColor={colors.gray}
              value={password}
              onChangeText={setPassword}
              secureTextEntry={!showPassword}
            />
            <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
              {showPassword ? (
                <EyeOff size={20} color={colors.gray} />
              ) : (
                <Eye size={20} color={colors.gray} />
              )}
            </TouchableOpacity>
          </View>
          
          <View style={[styles.inputContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Shield size={20} color={colors.gray} style={styles.inputIcon} />
            <TextInput
              style={[styles.input, { color: colors.text }]}
              placeholder="Confirm Password"
              placeholderTextColor={colors.gray}
              value={confirmPassword}
              onChangeText={setConfirmPassword}
              secureTextEntry={!showPassword}
            />
          </View>
          
          <View style={styles.roleContainer}>
            <Text style={[styles.roleLabel, { color: colors.text }]}>Admin Role:</Text>
            
            <View style={styles.roleButtons}>
              <TouchableOpacity
                style={[
                  styles.roleButton,
                  { 
                    backgroundColor: role === 'manager' ? colors.primary : colors.card,
                    borderColor: colors.border,
                  }
                ]}
                onPress={() => setRole('manager')}
              >
                <Text style={[
                  styles.roleButtonText,
                  { color: role === 'manager' ? '#000000' : colors.text }
                ]}>
                  Manager
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[
                  styles.roleButton,
                  { 
                    backgroundColor: role === 'owner' ? colors.primary : colors.card,
                    borderColor: colors.border,
                  }
                ]}
                onPress={() => setRole('owner')}
              >
                <Text style={[
                  styles.roleButtonText,
                  { color: role === 'owner' ? '#000000' : colors.text }
                ]}>
                  Owner
                </Text>
              </TouchableOpacity>
            </View>
          </View>
          
          <View style={styles.roleInfoContainer}>
            <Text style={[styles.roleInfoTitle, { color: colors.text }]}>Role Permissions:</Text>
            <Text style={[styles.roleInfoText, { color: colors.grayDark }]}>
              • <Text style={{ fontFamily: 'Montserrat-Medium' }}>Manager:</Text> Can manage members, but cannot add or remove other admins.
            </Text>
            <Text style={[styles.roleInfoText, { color: colors.grayDark }]}>
              • <Text style={{ fontFamily: 'Montserrat-Medium' }}>Owner:</Text> Full access to all features, including admin management.
            </Text>
          </View>
          
          <TouchableOpacity
            style={[styles.submitButton, { backgroundColor: colors.primary }]}
            onPress={handleSubmit}
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <ActivityIndicator size="small" color="#000000" />
            ) : (
              <Text style={styles.submitButtonText}>Add Admin</Text>
            )}
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  header: {
    marginBottom: 24,
  },
  headerTitle: {
    fontSize: 24,
    fontFamily: 'Montserrat-Bold',
  },
  formSection: {
    marginBottom: 24,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 16,
    marginBottom: 16,
    height: 56,
  },
  inputIcon: {
    marginRight: 12,
  },
  input: {
    flex: 1,
    height: 56,
    fontFamily: 'Montserrat-Regular',
    fontSize: 16,
  },
  roleContainer: {
    marginBottom: 16,
  },
  roleLabel: {
    fontSize: 16,
    fontFamily: 'Montserrat-Medium',
    marginBottom: 12,
  },
  roleButtons: {
    flexDirection: 'row',
  },
  roleButton: {
    flex: 1,
    height: 48,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
  },
  roleButtonText: {
    fontSize: 16,
    fontFamily: 'Montserrat-Medium',
  },
  roleInfoContainer: {
    marginTop: 8,
    marginBottom: 24,
  },
  roleInfoTitle: {
    fontSize: 16,
    fontFamily: 'Montserrat-Medium',
    marginBottom: 8,
  },
  roleInfoText: {
    fontSize: 14,
    fontFamily: 'Montserrat-Regular',
    marginBottom: 4,
    lineHeight: 20,
  },
  submitButton: {
    height: 56,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 8,
  },
  submitButtonText: {
    fontSize: 16,
    fontFamily: 'Montserrat-Bold',
    color: '#000000',
  },
});