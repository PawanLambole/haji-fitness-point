import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  TouchableOpacity, 
  Alert, 
  ActivityIndicator,
  Image,
  TextInput
} from 'react-native';
import { useTheme } from '@/context/ThemeContext';
import { useAuth } from '@/context/AuthContext';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { getDocument, updateDocument, deleteDocument, sendWhatsAppMessage } from '@/services/firebase';
import { Member } from '@/types';
import { CreditCard as Edit, Trash2, ChevronLeft, Phone, Calendar, DollarSign, Send, User, UserCheck, CircleCheck as CheckCircle } from 'lucide-react-native';
import DateTimePicker from '@react-native-community/datetimepicker';

export default function MemberDetailsScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { colors } = useTheme();
  const { currentUser } = useAuth();
  const router = useRouter();
  
  const [member, setMember] = useState<Member | null>(null);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isSendingMessage, setIsSendingMessage] = useState(false);
  
  // Edit form states
  const [editedMember, setEditedMember] = useState<Partial<Member>>({});
  const [showStartDatePicker, setShowStartDatePicker] = useState(false);
  const [showEndDatePicker, setShowEndDatePicker] = useState(false);
  
  useEffect(() => {
    if (id) {
      fetchMemberDetails();
    }
  }, [id]);
  
  const fetchMemberDetails = async () => {
    try {
      setLoading(true);
      const memberDoc = await getDocument('members', id);
      if (memberDoc.exists()) {
        const memberData = { id, ...memberDoc.data() } as Member;
        setMember(memberData);
        setEditedMember(memberData);
      } else {
        Alert.alert('Error', 'Member not found');
        router.back();
      }
    } catch (error) {
      console.error('Error fetching member details:', error);
      Alert.alert('Error', 'Failed to load member details');
    } finally {
      setLoading(false);
    }
  };
  
  const handleEdit = () => {
    setIsEditing(true);
  };
  
  const handleCancel = () => {
    setEditedMember(member || {});
    setIsEditing(false);
  };
  
  const handleSave = async () => {
    if (!member || !editedMember) return;
    
    try {
      setIsSaving(true);
      
      await updateDocument('members', member.id, {
        ...editedMember,
        updatedAt: Date.now()
      });
      
      // Refresh member data
      fetchMemberDetails();
      setIsEditing(false);
      Alert.alert('Success', 'Member updated successfully');
    } catch (error) {
      console.error('Error updating member:', error);
      Alert.alert('Error', 'Failed to update member');
    } finally {
      setIsSaving(false);
    }
  };
  
  const handleDelete = () => {
    Alert.alert(
      'Delete Member',
      'Are you sure you want to delete this member? This action cannot be undone.',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: confirmDelete,
        },
      ]
    );
  };
  
  const confirmDelete = async () => {
    if (!member) return;
    
    try {
      setIsDeleting(true);
      await deleteDocument('members', member.id);
      Alert.alert('Success', 'Member deleted successfully');
      router.back();
    } catch (error) {
      console.error('Error deleting member:', error);
      Alert.alert('Error', 'Failed to delete member');
      setIsDeleting(false);
    }
  };
  
  const handleResendWhatsApp = async () => {
    if (!member) return;
    
    try {
      setIsSendingMessage(true);
      
      const startDateFormatted = new Date(member.membershipStartDate).toLocaleDateString();
      const endDateFormatted = new Date(member.membershipEndDate).toLocaleDateString();
      
      const messageResult = await sendWhatsAppMessage(
        member.phoneNumber,
        member.fullName,
        startDateFormatted,
        endDateFormatted
      );
      
      if (messageResult.success) {
        await updateDocument('members', member.id, { whatsappMessageSent: true });
        Alert.alert('Success', 'WhatsApp message sent successfully');
        fetchMemberDetails();
      } else {
        Alert.alert('Error', 'Failed to send WhatsApp message');
      }
    } catch (error) {
      console.error('Error sending WhatsApp message:', error);
      Alert.alert('Error', 'Failed to send WhatsApp message');
    } finally {
      setIsSendingMessage(false);
    }
  };
  
  if (loading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: colors.background }]}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }
  
  if (!member) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: colors.background }]}>
        <Text style={[styles.errorText, { color: colors.error }]}>
          Member not found
        </Text>
        <TouchableOpacity
          style={[styles.backButton, { backgroundColor: colors.primary }]}
          onPress={() => router.back()}
        >
          <Text style={styles.backButtonText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }
  
  const isActive = new Date(member.membershipEndDate) >= new Date();
  
  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { backgroundColor: colors.card }]}>
        <TouchableOpacity
          style={styles.backButtonContainer}
          onPress={() => router.back()}
        >
          <ChevronLeft size={24} color={colors.text} />
        </TouchableOpacity>
        
        <View style={styles.headerActions}>
          {!isEditing ? (
            <>
              <TouchableOpacity
                style={[styles.actionButton, { backgroundColor: colors.primary + '20' }]}
                onPress={handleEdit}
              >
                <Edit size={20} color={colors.primary} />
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[styles.actionButton, { backgroundColor: colors.error + '20' }]}
                onPress={handleDelete}
                disabled={isDeleting}
              >
                {isDeleting ? (
                  <ActivityIndicator size="small" color={colors.error} />
                ) : (
                  <Trash2 size={20} color={colors.error} />
                )}
              </TouchableOpacity>
            </>
          ) : (
            <>
              <TouchableOpacity
                style={[styles.textButton, { backgroundColor: colors.error + '20' }]}
                onPress={handleCancel}
              >
                <Text style={[styles.textButtonText, { color: colors.error }]}>Cancel</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[styles.textButton, { backgroundColor: colors.primary }]}
                onPress={handleSave}
                disabled={isSaving}
              >
                {isSaving ? (
                  <ActivityIndicator size="small" color="#000000" />
                ) : (
                  <Text style={styles.saveButtonText}>Save</Text>
                )}
              </TouchableOpacity>
            </>
          )}
        </View>
      </View>
      
      <ScrollView style={styles.content}>
        <View style={styles.profileSection}>
          <View style={[styles.photoContainer, { backgroundColor: colors.card }]}>
            {member.photoURL ? (
              <Image source={{ uri: member.photoURL }} style={styles.photo} />
            ) : (
              <User size={64} color={colors.grayLight} />
            )}
          </View>
          
          {isEditing ? (
            <TextInput
              style={[styles.nameInput, { color: colors.text, borderColor: colors.border, backgroundColor: colors.card }]}
              value={editedMember.fullName}
              onChangeText={(text) => setEditedMember({ ...editedMember, fullName: text })}
            />
          ) : (
            <Text style={[styles.memberName, { color: colors.text }]}>{member.fullName}</Text>
          )}
          
          <View style={[
            styles.statusBadge,
            { backgroundColor: isActive ? colors.success + '20' : colors.error + '20' }
          ]}>
            <Text style={[
              styles.statusText,
              { color: isActive ? colors.success : colors.error }
            ]}>
              {isActive ? 'Active Member' : 'Membership Expired'}
            </Text>
          </View>
        </View>
        
        <View style={styles.detailsSection}>
          <View style={[styles.detailCard, { backgroundColor: colors.card }]}>
            <Text style={[styles.detailCardTitle, { color: colors.text }]}>Basic Information</Text>
            
            <View style={styles.detailRow}>
              <View style={styles.detailLabelContainer}>
                <Text style={[styles.detailLabel, { color: colors.grayDark }]}>ID Number:</Text>
              </View>
              
              {isEditing ? (
                <TextInput
                  style={[styles.detailInput, { color: colors.text, borderColor: colors.border, backgroundColor: colors.background }]}
                  value={editedMember.assignmentNumber}
                  onChangeText={(text) => setEditedMember({ ...editedMember, assignmentNumber: text })}
                  keyboardType="number-pad"
                />
              ) : (
                <Text style={[styles.detailValue, { color: colors.text }]}>
                  #{member.assignmentNumber}
                </Text>
              )}
            </View>
            
            <View style={styles.detailRow}>
              <View style={styles.detailLabelContainer}>
                <Text style={[styles.detailLabel, { color: colors.grayDark }]}>Phone Number:</Text>
              </View>
              
              {isEditing ? (
                <TextInput
                  style={[styles.detailInput, { color: colors.text, borderColor: colors.border, backgroundColor: colors.background }]}
                  value={editedMember.phoneNumber}
                  onChangeText={(text) => setEditedMember({ ...editedMember, phoneNumber: text })}
                  keyboardType="phone-pad"
                  maxLength={10}
                />
              ) : (
                <View style={styles.phoneContainer}>
                  <Text style={[styles.detailValue, { color: colors.text }]}>
                    {member.phoneNumber}
                  </Text>
                  <TouchableOpacity
                    style={[styles.messageButton, { backgroundColor: colors.primary + '20' }]}
                    onPress={handleResendWhatsApp}
                    disabled={isSendingMessage}
                  >
                    {isSendingMessage ? (
                      <ActivityIndicator size="small" color={colors.primary} />
                    ) : (
                      <>
                        <Send size={14} color={colors.primary} />
                        <Text style={[styles.messageButtonText, { color: colors.primary }]}>
                          {member.whatsappMessageSent ? 'Resend' : 'Send'}
                        </Text>
                      </>
                    )}
                  </TouchableOpacity>
                </View>
              )}
            </View>
            
            <View style={styles.detailRow}>
              <View style={styles.detailLabelContainer}>
                <Text style={[styles.detailLabel, { color: colors.grayDark }]}>Joining Date:</Text>
              </View>
              
              <Text style={[styles.detailValue, { color: colors.text }]}>
                {new Date(member.joiningDate).toLocaleDateString()}
              </Text>
            </View>
          </View>
          
          <View style={[styles.detailCard, { backgroundColor: colors.card }]}>
            <Text style={[styles.detailCardTitle, { color: colors.text }]}>Membership Details</Text>
            
            <View style={styles.detailRow}>
              <View style={styles.detailLabelContainer}>
                <Text style={[styles.detailLabel, { color: colors.grayDark }]}>Start Date:</Text>
              </View>
              
              {isEditing ? (
                <TouchableOpacity
                  style={[styles.datePickerButton, { backgroundColor: colors.background, borderColor: colors.border }]}
                  onPress={() => setShowStartDatePicker(true)}
                >
                  <Text style={[styles.detailValue, { color: colors.text }]}>
                    {new Date(editedMember.membershipStartDate || 0).toLocaleDateString()}
                  </Text>
                  
                  {showStartDatePicker && (
                    <DateTimePicker
                      value={new Date(editedMember.membershipStartDate || Date.now())}
                      mode="date"
                      display="default"
                      onChange={(event, selectedDate) => {
                        setShowStartDatePicker(false);
                        if (selectedDate) {
                          setEditedMember({
                            ...editedMember,
                            membershipStartDate: selectedDate.getTime()
                          });
                        }
                      }}
                    />
                  )}
                </TouchableOpacity>
              ) : (
                <Text style={[styles.detailValue, { color: colors.text }]}>
                  {new Date(member.membershipStartDate).toLocaleDateString()}
                </Text>
              )}
            </View>
            
            <View style={styles.detailRow}>
              <View style={styles.detailLabelContainer}>
                <Text style={[styles.detailLabel, { color: colors.grayDark }]}>End Date:</Text>
              </View>
              
              {isEditing ? (
                <TouchableOpacity
                  style={[styles.datePickerButton, { backgroundColor: colors.background, borderColor: colors.border }]}
                  onPress={() => setShowEndDatePicker(true)}
                >
                  <Text style={[styles.detailValue, { color: colors.text }]}>
                    {new Date(editedMember.membershipEndDate || 0).toLocaleDateString()}
                  </Text>
                  
                  {showEndDatePicker && (
                    <DateTimePicker
                      value={new Date(editedMember.membershipEndDate || Date.now())}
                      mode="date"
                      display="default"
                      onChange={(event, selectedDate) => {
                        setShowEndDatePicker(false);
                        if (selectedDate) {
                          setEditedMember({
                            ...editedMember,
                            membershipEndDate: selectedDate.getTime()
                          });
                        }
                      }}
                    />
                  )}
                </TouchableOpacity>
              ) : (
                <Text style={[
                  styles.detailValue, 
                  { color: isActive ? colors.text : colors.error }
                ]}>
                  {new Date(member.membershipEndDate).toLocaleDateString()}
                </Text>
              )}
            </View>
            
            <View style={styles.detailRow}>
              <View style={styles.detailLabelContainer}>
                <Text style={[styles.detailLabel, { color: colors.grayDark }]}>Duration:</Text>
              </View>
              
              <Text style={[styles.detailValue, { color: colors.text }]}>
                {Math.ceil((member.membershipEndDate - member.membershipStartDate) / (1000 * 60 * 60 * 24))} days
              </Text>
            </View>
          </View>
          
          <View style={[styles.detailCard, { backgroundColor: colors.card }]}>
            <Text style={[styles.detailCardTitle, { color: colors.text }]}>Payment Information</Text>
            
            <View style={styles.detailRow}>
              <View style={styles.detailLabelContainer}>
                <Text style={[styles.detailLabel, { color: colors.grayDark }]}>Total Amount:</Text>
              </View>
              
              {isEditing ? (
                <TextInput
                  style={[styles.detailInput, { color: colors.text, borderColor: colors.border, backgroundColor: colors.background }]}
                  value={editedMember.totalAmount?.toString()}
                  onChangeText={(text) => setEditedMember({ ...editedMember, totalAmount: parseFloat(text) || 0 })}
                  keyboardType="numeric"
                />
              ) : (
                <Text style={[styles.detailValue, { color: colors.text }]}>
                  ₹{member.totalAmount}
                </Text>
              )}
            </View>
            
            <View style={styles.detailRow}>
              <View style={styles.detailLabelContainer}>
                <Text style={[styles.detailLabel, { color: colors.grayDark }]}>Discount:</Text>
              </View>
              
              {isEditing ? (
                <TextInput
                  style={[styles.detailInput, { color: colors.text, borderColor: colors.border, backgroundColor: colors.background }]}
                  value={editedMember.discountAmount?.toString()}
                  onChangeText={(text) => setEditedMember({ ...editedMember, discountAmount: parseFloat(text) || 0 })}
                  keyboardType="numeric"
                />
              ) : (
                <Text style={[styles.detailValue, { color: colors.text }]}>
                  ₹{member.discountAmount}
                </Text>
              )}
            </View>
            
            <View style={styles.detailRow}>
              <View style={styles.detailLabelContainer}>
                <Text style={[styles.detailLabel, { color: colors.grayDark }]}>Final Amount:</Text>
              </View>
              
              <Text style={[styles.detailValue, { color: colors.text, fontFamily: 'Montserrat-Bold' }]}>
                ₹{member.totalAmount - member.discountAmount}
              </Text>
            </View>
            
            <View style={styles.detailRow}>
              <View style={styles.detailLabelContainer}>
                <Text style={[styles.detailLabel, { color: colors.grayDark }]}>Payment Method:</Text>
              </View>
              
              {isEditing ? (
                <View style={styles.paymentMethodContainer}>
                  <TouchableOpacity
                    style={[
                      styles.paymentButton,
                      { 
                        backgroundColor: editedMember.paymentMethod?.cash ? colors.primary : colors.background,
                        borderColor: colors.border
                      }
                    ]}
                    onPress={() => setEditedMember({
                      ...editedMember,
                      paymentMethod: { cash: 1, upi: 0 }
                    })}
                  >
                    <Text style={[
                      styles.paymentButtonText,
                      { color: editedMember.paymentMethod?.cash ? '#000000' : colors.text }
                    ]}>
                      Cash
                    </Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity
                    style={[
                      styles.paymentButton,
                      { 
                        backgroundColor: editedMember.paymentMethod?.upi ? colors.primary : colors.background,
                        borderColor: colors.border
                      }
                    ]}
                    onPress={() => setEditedMember({
                      ...editedMember,
                      paymentMethod: { cash: 0, upi: 1 }
                    })}
                  >
                    <Text style={[
                      styles.paymentButtonText,
                      { color: editedMember.paymentMethod?.upi ? '#000000' : colors.text }
                    ]}>
                      UPI
                    </Text>
                  </TouchableOpacity>
                </View>
              ) : (
                <Text style={[styles.detailValue, { color: colors.text }]}>
                  {member.paymentMethod.cash > 0 ? 'Cash' : 'UPI'}
                  {` (${member.paymentMethod.cash || member.paymentMethod.upi} time${(member.paymentMethod.cash || member.paymentMethod.upi) > 1 ? 's' : ''})`}
                </Text>
              )}
            </View>
          </View>
          
          <View style={[styles.detailCard, { backgroundColor: colors.card }]}>
            <Text style={[styles.detailCardTitle, { color: colors.text }]}>Other Information</Text>
            
            <View style={styles.detailRow}>
              <View style={styles.detailLabelContainer}>
                <Text style={[styles.detailLabel, { color: colors.grayDark }]}>WhatsApp Status:</Text>
              </View>
              
              <View style={styles.statusContainer}>
                {member.whatsappMessageSent ? (
                  <>
                    <CheckCircle size={16} color={colors.success} />
                    <Text style={[styles.statusValueText, { color: colors.success }]}>
                      Message Sent
                    </Text>
                  </>
                ) : (
                  <>
                    <Send size={16} color={colors.warning} />
                    <Text style={[styles.statusValueText, { color: colors.warning }]}>
                      Not Sent
                    </Text>
                  </>
                )}
              </View>
            </View>
            
            <View style={styles.detailRow}>
              <View style={styles.detailLabelContainer}>
                <Text style={[styles.detailLabel, { color: colors.grayDark }]}>Created At:</Text>
              </View>
              
              <Text style={[styles.detailValue, { color: colors.text }]}>
                {new Date(member.createdAt).toLocaleDateString()}
              </Text>
            </View>
            
            <View style={styles.detailRow}>
              <View style={styles.detailLabelContainer}>
                <Text style={[styles.detailLabel, { color: colors.grayDark }]}>Last Updated:</Text>
              </View>
              
              <Text style={[styles.detailValue, { color: colors.text }]}>
                {new Date(member.updatedAt).toLocaleDateString()}
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#e1e1e1',
  },
  backButtonContainer: {
    padding: 8,
  },
  headerActions: {
    flexDirection: 'row',
  },
  actionButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
  textButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    marginLeft: 8,
  },
  textButtonText: {
    fontFamily: 'Montserrat-Medium',
    fontSize: 14,
  },
  saveButtonText: {
    fontFamily: 'Montserrat-Medium',
    fontSize: 14,
    color: '#000000',
  },
  content: {
    flex: 1,
  },
  profileSection: {
    alignItems: 'center',
    paddingVertical: 24,
  },
  photoContainer: {
    width: 100,
    height: 100,
    borderRadius: 50,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    overflow: 'hidden',
  },
  photo: {
    width: '100%',
    height: '100%',
  },
  memberName: {
    fontSize: 24,
    fontFamily: 'Montserrat-Bold',
    marginBottom: 8,
  },
  nameInput: {
    fontSize: 24,
    fontFamily: 'Montserrat-Bold',
    marginBottom: 8,
    padding: 8,
    borderWidth: 1,
    borderRadius: 8,
    textAlign: 'center',
    minWidth: 200,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  statusText: {
    fontSize: 14,
    fontFamily: 'Montserrat-Medium',
  },
  detailsSection: {
    padding: 16,
  },
  detailCard: {
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  detailCardTitle: {
    fontSize: 18,
    fontFamily: 'Montserrat-Bold',
    marginBottom: 16,
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  detailLabelContainer: {
    flex: 1,
  },
  detailLabel: {
    fontSize: 14,
    fontFamily: 'Montserrat-Regular',
  },
  detailValue: {
    fontSize: 16,
    fontFamily: 'Montserrat-Medium',
    flex: 1,
    textAlign: 'right',
  },
  detailInput: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'Montserrat-Medium',
    textAlign: 'right',
    padding: 8,
    borderWidth: 1,
    borderRadius: 8,
  },
  datePickerButton: {
    flex: 1,
    padding: 8,
    borderWidth: 1,
    borderRadius: 8,
  },
  phoneContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  messageButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
    marginLeft: 8,
  },
  messageButtonText: {
    fontSize: 12,
    fontFamily: 'Montserrat-Medium',
    marginLeft: 4,
  },
  statusContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  statusValueText: {
    fontSize: 16,
    fontFamily: 'Montserrat-Medium',
    marginLeft: 8,
  },
  paymentMethodContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  paymentButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
    marginLeft: 8,
  },
  paymentButtonText: {
    fontSize: 14,
    fontFamily: 'Montserrat-Medium',
  },
  errorText: {
    fontSize: 18,
    fontFamily: 'Montserrat-Medium',
    marginBottom: 16,
  },
  backButton: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  backButtonText: {
    fontSize: 16,
    fontFamily: 'Montserrat-Medium',
    color: '#000000',
  },
});