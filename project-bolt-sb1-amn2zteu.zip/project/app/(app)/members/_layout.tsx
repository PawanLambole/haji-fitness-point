import { Stack } from 'expo-router';

export default function MembersLayout() {
  return (
    <Stack>
      <Stack.Screen 
        name="index" 
        options={{ 
          headerShown: false,
        }} 
      />
      <Stack.Screen 
        name="add" 
        options={{ 
          title: 'Add New Member',
          presentation: 'modal'
        }} 
      />
      <Stack.Screen 
        name="[id]" 
        options={{ 
          title: 'Member Details',
        }} 
      />
    </Stack>
  );
}