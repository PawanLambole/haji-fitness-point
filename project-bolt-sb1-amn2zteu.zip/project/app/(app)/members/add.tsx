import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TextInput, 
  TouchableOpacity, 
  ScrollView, 
  KeyboardAvoidingView, 
  Platform,
  Alert,
  Image,
  ActivityIndicator
} from 'react-native';
import { useTheme } from '@/context/ThemeContext';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Camera, CameraType } from 'expo-camera';
import { 
  setDocument, 
  updateDocument, 
  getCollection, 
  queryCollection, 
  sendWhatsAppMessage 
} from '@/services/firebase';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { Member } from '@/types';
import { User, Calendar, DollarSign, Phone, Camera as CameraIcon, Upload } from 'lucide-react-native';

export default function AddMemberScreen() {
  const { colors } = useTheme();
  const { currentUser } = useAuth();
  const router = useRouter();
  
  const [fullName, setFullName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [assignmentNumber, setAssignmentNumber] = useState('');
  const [joiningDate, setJoiningDate] = useState(new Date());
  const [membershipStartDate, setMembershipStartDate] = useState(new Date());
  const [membershipEndDate, setMembershipEndDate] = useState(new Date(new Date().setMonth(new Date().getMonth() + 1)));
  const [totalAmount, setTotalAmount] = useState('');
  const [discountAmount, setDiscountAmount] = useState('0');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'upi'>('cash');
  const [photo, setPhoto] = useState<string | null>(null);
  
  const [showJoiningDatePicker, setShowJoiningDatePicker] = useState(false);
  const [showStartDatePicker, setShowStartDatePicker] = useState(false);
  const [showEndDatePicker, setShowEndDatePicker] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const handleSelectImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission required', 'Please allow access to your photo library');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });

    if (!result.canceled && result.assets && result.assets.length > 0) {
      setPhoto(result.assets[0].uri);
    }
  };

  const handleTakePhoto = async () => {
    const { status } = await Camera.requestCameraPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission required', 'Please allow access to camera');
      return;
    }

    Alert.alert(
      'Camera',
      'This feature will use the camera to take a photo',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Continue',
          onPress: () => {
            // In a real app, we would navigate to a camera screen
            // For this example, we'll just use the image picker
            handleSelectImage();
          },
        },
      ]
    );
  };

  const generateAssignmentNumber = async () => {
    if (assignmentNumber) return;
    
    try {
      const membersSnapshot = await queryCollection('members', [], 'createdAt', 'desc');
      let highestNumber = 0;
      
      membersSnapshot.docs.forEach(doc => {
        const member = doc.data() as Member;
        const num = parseInt(member.assignmentNumber);
        if (!isNaN(num) && num > highestNumber) {
          highestNumber = num;
        }
      });
      
      setAssignmentNumber((highestNumber + 1).toString().padStart(3, '0'));
    } catch (error) {
      console.error('Error generating assignment number:', error);
      // Fallback to current timestamp
      setAssignmentNumber(Date.now().toString().slice(-3));
    }
  };

  const validateForm = () => {
    if (!fullName) {
      Alert.alert('Error', 'Please enter member name');
      return false;
    }
    
    if (!phoneNumber || phoneNumber.length < 10) {
      Alert.alert('Error', 'Please enter a valid phone number');
      return false;
    }
    
    if (!assignmentNumber) {
      Alert.alert('Error', 'Please enter an assignment number');
      return false;
    }
    
    if (!totalAmount || isNaN(parseFloat(totalAmount))) {
      Alert.alert('Error', 'Please enter a valid amount');
      return false;
    }
    
    return true;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;
    if (!currentUser) {
      Alert.alert('Error', 'You must be logged in to add a member');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Create a new member ID
      const memberCollection = getCollection('members');
      const memberId = Date.now().toString();
      
      let photoURL = '';
      
      // Upload photo if available
      if (photo) {
        const storage = getStorage();
        const photoRef = ref(storage, `member-photos/${memberId}`);
        
        // Convert URI to blob
        const response = await fetch(photo);
        const blob = await response.blob();
        
        // Upload to Firebase Storage
        const snapshot = await uploadBytes(photoRef, blob);
        photoURL = await getDownloadURL(snapshot.ref);
      }
      
      // Create member document
      const memberData: Omit<Member, 'id'> = {
        assignmentNumber,
        fullName,
        phoneNumber,
        joiningDate: joiningDate.getTime(),
        membershipStartDate: membershipStartDate.getTime(),
        membershipEndDate: membershipEndDate.getTime(),
        totalAmount: parseFloat(totalAmount),
        discountAmount: parseFloat(discountAmount) || 0,
        paymentMethod: {
          cash: paymentMethod === 'cash' ? 1 : 0,
          upi: paymentMethod === 'upi' ? 1 : 0,
        },
        photoURL,
        whatsappMessageSent: false,
        createdBy: currentUser.id,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      
      await setDocument('members', memberId, memberData);
      
      // Send WhatsApp message
      const startDateFormatted = membershipStartDate.toLocaleDateString();
      const endDateFormatted = membershipEndDate.toLocaleDateString();
      
      const messageResult = await sendWhatsAppMessage(
        phoneNumber,
        fullName,
        startDateFormatted,
        endDateFormatted
      );
      
      if (messageResult.success) {
        await updateDocument('members', memberId, { whatsappMessageSent: true });
      }
      
      Alert.alert(
        'Success',
        'Member added successfully',
        [{ text: 'OK', onPress: () => router.back() }]
      );
    } catch (error) {
      console.error('Error adding member:', error);
      Alert.alert('Error', 'Failed to add member. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1 }}
    >
      <ScrollView style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={styles.header}>
          <Text style={[styles.headerTitle, { color: colors.text }]}>Add New Member</Text>
        </View>
        
        <View style={styles.photoSection}>
          <View style={[styles.photoContainer, { backgroundColor: colors.card }]}>
            {photo ? (
              <Image source={{ uri: photo }} style={styles.photo} />
            ) : (
              <User size={64} color={colors.grayLight} />
            )}
          </View>
          
          <View style={styles.photoButtons}>
            <TouchableOpacity
              style={[styles.photoButton, { backgroundColor: colors.card }]}
              onPress={handleSelectImage}
            >
              <Upload size={20} color={colors.primary} />
              <Text style={[styles.photoButtonText, { color: colors.text }]}>Gallery</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[styles.photoButton, { backgroundColor: colors.card }]}
              onPress={handleTakePhoto}
            >
              <CameraIcon size={20} color={colors.primary} />
              <Text style={[styles.photoButtonText, { color: colors.text }]}>Camera</Text>
            </TouchableOpacity>
          </View>
        </View>
        
        <View style={styles.formSection}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Personal Information</Text>
          
          <View style={[styles.inputContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <TextInput
              style={[styles.input, { color: colors.text }]}
              placeholder="Full Name"
              placeholderTextColor={colors.gray}
              value={fullName}
              onChangeText={setFullName}
            />
          </View>
          
          <View style={[styles.inputContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <TextInput
              style={[styles.input, { color: colors.text }]}
              placeholder="Phone Number"
              placeholderTextColor={colors.gray}
              value={phoneNumber}
              onChangeText={setPhoneNumber}
              keyboardType="phone-pad"
              maxLength={10}
            />
          </View>
          
          <View style={styles.row}>
            <View style={[styles.inputContainer, styles.inputHalf, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <TextInput
                style={[styles.input, { color: colors.text }]}
                placeholder="Assignment Number"
                placeholderTextColor={colors.gray}
                value={assignmentNumber}
                onChangeText={setAssignmentNumber}
                onFocus={generateAssignmentNumber}
                keyboardType="number-pad"
              />
            </View>
            
            <TouchableOpacity
              style={[styles.datePickerButton, styles.inputHalf, { backgroundColor: colors.card }]}
              onPress={() => setShowJoiningDatePicker(true)}
            >
              <Text style={[styles.datePickerButtonText, { color: colors.gray }]}>Joining Date</Text>
              <Text style={[styles.dateText, { color: colors.text }]}>
                {joiningDate.toLocaleDateString()}
              </Text>
              
              {showJoiningDatePicker && (
                <DateTimePicker
                  value={joiningDate}
                  mode="date"
                  display="default"
                  onChange={(event, selectedDate) => {
                    setShowJoiningDatePicker(false);
                    if (selectedDate) {
                      setJoiningDate(selectedDate);
                    }
                  }}
                />
              )}
            </TouchableOpacity>
          </View>
        </View>
        
        <View style={styles.formSection}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Membership Details</Text>
          
          <View style={styles.row}>
            <TouchableOpacity
              style={[styles.datePickerButton, styles.inputHalf, { backgroundColor: colors.card }]}
              onPress={() => setShowStartDatePicker(true)}
            >
              <Text style={[styles.datePickerButtonText, { color: colors.gray }]}>Start Date</Text>
              <Text style={[styles.dateText, { color: colors.text }]}>
                {membershipStartDate.toLocaleDateString()}
              </Text>
              
              {showStartDatePicker && (
                <DateTimePicker
                  value={membershipStartDate}
                  mode="date"
                  display="default"
                  onChange={(event, selectedDate) => {
                    setShowStartDatePicker(false);
                    if (selectedDate) {
                      setMembershipStartDate(selectedDate);
                    }
                  }}
                />
              )}
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[styles.datePickerButton, styles.inputHalf, { backgroundColor: colors.card }]}
              onPress={() => setShowEndDatePicker(true)}
            >
              <Text style={[styles.datePickerButtonText, { color: colors.gray }]}>End Date</Text>
              <Text style={[styles.dateText, { color: colors.text }]}>
                {membershipEndDate.toLocaleDateString()}
              </Text>
              
              {showEndDatePicker && (
                <DateTimePicker
                  value={membershipEndDate}
                  mode="date"
                  display="default"
                  onChange={(event, selectedDate) => {
                    setShowEndDatePicker(false);
                    if (selectedDate) {
                      setMembershipEndDate(selectedDate);
                    }
                  }}
                />
              )}
            </TouchableOpacity>
          </View>
        </View>
        
        <View style={styles.formSection}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Payment Information</Text>
          
          <View style={styles.row}>
            <View style={[styles.inputContainer, styles.inputHalf, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <TextInput
                style={[styles.input, { color: colors.text }]}
                placeholder="Total Amount"
                placeholderTextColor={colors.gray}
                value={totalAmount}
                onChangeText={setTotalAmount}
                keyboardType="numeric"
              />
            </View>
            
            <View style={[styles.inputContainer, styles.inputHalf, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <TextInput
                style={[styles.input, { color: colors.text }]}
                placeholder="Discount Amount"
                placeholderTextColor={colors.gray}
                value={discountAmount}
                onChangeText={setDiscountAmount}
                keyboardType="numeric"
              />
            </View>
          </View>
          
          <View style={styles.paymentMethodContainer}>
            <Text style={[styles.paymentMethodLabel, { color: colors.text }]}>Payment Method:</Text>
            
            <View style={styles.paymentButtons}>
              <TouchableOpacity
                style={[
                  styles.paymentButton,
                  { backgroundColor: paymentMethod === 'cash' ? colors.primary : colors.card }
                ]}
                onPress={() => setPaymentMethod('cash')}
              >
                <Text style={[
                  styles.paymentButtonText,
                  { color: paymentMethod === 'cash' ? '#000000' : colors.text }
                ]}>
                  Cash
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[
                  styles.paymentButton,
                  { backgroundColor: paymentMethod === 'upi' ? colors.primary : colors.card }
                ]}
                onPress={() => setPaymentMethod('upi')}
              >
                <Text style={[
                  styles.paymentButtonText,
                  { color: paymentMethod === 'upi' ? '#000000' : colors.text }
                ]}>
                  UPI
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
        
        <TouchableOpacity
          style={[styles.submitButton, { backgroundColor: colors.primary }]}
          onPress={handleSubmit}
          disabled={isSubmitting}
        >
          {isSubmitting ? (
            <ActivityIndicator size="small" color="#000000" />
          ) : (
            <Text style={styles.submitButtonText}>Add Member</Text>
          )}
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  header: {
    marginBottom: 24,
  },
  headerTitle: {
    fontSize: 24,
    fontFamily: 'Montserrat-Bold',
  },
  photoSection: {
    alignItems: 'center',
    marginBottom: 24,
  },
  photoContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    overflow: 'hidden',
  },
  photo: {
    width: '100%',
    height: '100%',
  },
  photoButtons: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  photoButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 8,
    marginHorizontal: 8,
  },
  photoButtonText: {
    marginLeft: 8,
    fontFamily: 'Montserrat-Medium',
    fontSize: 14,
  },
  formSection: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Montserrat-Bold',
    marginBottom: 16,
  },
  inputContainer: {
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 16,
    marginBottom: 16,
    height: 56,
    justifyContent: 'center',
  },
  input: {
    fontFamily: 'Montserrat-Regular',
    fontSize: 16,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  inputHalf: {
    width: '48%',
  },
  datePickerButton: {
    borderRadius: 8,
    paddingHorizontal: 16,
    marginBottom: 16,
    height: 56,
    justifyContent: 'center',
  },
  datePickerButtonText: {
    fontSize: 14,
    fontFamily: 'Montserrat-Regular',
    marginBottom: 4,
  },
  dateText: {
    fontSize: 16,
    fontFamily: 'Montserrat-Medium',
  },
  paymentMethodContainer: {
    marginBottom: 16,
  },
  paymentMethodLabel: {
    fontSize: 16,
    fontFamily: 'Montserrat-Medium',
    marginBottom: 8,
  },
  paymentButtons: {
    flexDirection: 'row',
  },
  paymentButton: {
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
    marginRight: 16,
  },
  paymentButtonText: {
    fontFamily: 'Montserrat-Medium',
    fontSize: 14,
  },
  submitButton: {
    height: 56,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 40,
  },
  submitButtonText: {
    fontSize: 16,
    fontFamily: 'Montserrat-Bold',
    color: '#000000',
  },
});