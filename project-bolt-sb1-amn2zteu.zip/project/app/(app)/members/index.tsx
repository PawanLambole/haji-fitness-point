import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  FlatList, 
  TouchableOpacity, 
  ActivityIndicator,
  TextInput,
  Alert
} from 'react-native';
import { useTheme } from '@/context/ThemeContext';
import { useRouter } from 'expo-router';
import { queryCollection, orderBy, where } from '@/services/firebase';
import { Member } from '@/types';
import { Plus, Search, SlidersHorizontal, UserX, Calendar, Filter } from 'lucide-react-native';

export default function MembersScreen() {
  const { colors } = useTheme();
  const router = useRouter();
  const [members, setMembers] = useState<Member[]>([]);
  const [filteredMembers, setFilteredMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'assignmentNumber' | 'joiningDate'>('assignmentNumber');
  const [filterActive, setFilterActive] = useState<boolean | null>(null); // null = all, true = active, false = expired

  useEffect(() => {
    fetchMembers();
  }, []);

  useEffect(() => {
    if (members.length > 0) {
      let result = [...members];
      
      // Apply search filter
      if (searchQuery) {
        const lowerCaseQuery = searchQuery.toLowerCase();
        result = result.filter(member => 
          member.fullName.toLowerCase().includes(lowerCaseQuery) || 
          member.assignmentNumber.includes(searchQuery) ||
          member.phoneNumber.includes(searchQuery)
        );
      }
      
      // Apply active/expired filter
      if (filterActive !== null) {
        const now = new Date();
        result = result.filter(member => {
          const isActive = new Date(member.membershipEndDate) >= now;
          return filterActive ? isActive : !isActive;
        });
      }
      
      // Apply sorting
      if (sortBy === 'assignmentNumber') {
        result.sort((a, b) => a.assignmentNumber.localeCompare(b.assignmentNumber));
      } else {
        result.sort((a, b) => b.joiningDate - a.joiningDate);
      }
      
      setFilteredMembers(result);
    }
  }, [members, searchQuery, sortBy, filterActive]);

  const fetchMembers = async () => {
    try {
      setLoading(true);
      const membersSnapshot = await queryCollection('members', [], 'createdAt', 'desc');
      const membersData = membersSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Member[];
      
      setMembers(membersData);
      setFilteredMembers(membersData);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching members:', error);
      setLoading(false);
    }
  };

  const handleAddMember = () => {
    router.push('/members/add');
  };

  const toggleSortBy = () => {
    setSortBy(sortBy === 'assignmentNumber' ? 'joiningDate' : 'assignmentNumber');
  };

  const toggleFilter = () => {
    // Cycle through: null (all) -> true (active) -> false (expired) -> null (all)
    setFilterActive(filterActive === null ? true : filterActive === true ? false : null);
  };

  const getFilterLabel = () => {
    if (filterActive === null) return 'All Members';
    if (filterActive === true) return 'Active Members';
    return 'Expired Members';
  };

  const renderMemberItem = ({ item }: { item: Member }) => {
    const isActive = new Date(item.membershipEndDate) >= new Date();
    
    return (
      <TouchableOpacity
        style={[styles.memberCard, { backgroundColor: colors.card }]}
        onPress={() => router.push(`/members/${item.id}`)}
      >
        <View style={styles.memberHeader}>
          <Text style={[styles.memberName, { color: colors.text }]}>{item.fullName}</Text>
          <View style={[
            styles.statusBadge, 
            { backgroundColor: isActive ? colors.success + '20' : colors.error + '20' }
          ]}>
            <Text style={[
              styles.statusText, 
              { color: isActive ? colors.success : colors.error }
            ]}>
              {isActive ? 'Active' : 'Expired'}
            </Text>
          </View>
        </View>
        
        <View style={styles.memberDetails}>
          <View style={styles.memberDetailItem}>
            <Text style={[styles.memberDetailLabel, { color: colors.grayDark }]}>ID:</Text>
            <Text style={[styles.memberDetailValue, { color: colors.text }]}>#{item.assignmentNumber}</Text>
          </View>
          
          <View style={styles.memberDetailItem}>
            <Text style={[styles.memberDetailLabel, { color: colors.grayDark }]}>Phone:</Text>
            <Text style={[styles.memberDetailValue, { color: colors.text }]}>{item.phoneNumber}</Text>
          </View>
          
          <View style={styles.memberDetailItem}>
            <Text style={[styles.memberDetailLabel, { color: colors.grayDark }]}>Joined:</Text>
            <Text style={[styles.memberDetailValue, { color: colors.text }]}>
              {new Date(item.joiningDate).toLocaleDateString()}
            </Text>
          </View>
          
          <View style={styles.memberDetailItem}>
            <Text style={[styles.memberDetailLabel, { color: colors.grayDark }]}>Expires:</Text>
            <Text style={[styles.memberDetailValue, { color: isActive ? colors.text : colors.error }]}>
              {new Date(item.membershipEndDate).toLocaleDateString()}
            </Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <Text style={[styles.headerTitle, { color: colors.text }]}>Members</Text>
        <TouchableOpacity
          style={[styles.addButton, { backgroundColor: colors.primary }]}
          onPress={handleAddMember}
        >
          <Plus size={24} color="#000000" />
        </TouchableOpacity>
      </View>
      
      <View style={[styles.searchContainer, { backgroundColor: colors.card }]}>
        <Search size={20} color={colors.gray} />
        <TextInput
          style={[styles.searchInput, { color: colors.text }]}
          placeholder="Search by name, ID or phone"
          placeholderTextColor={colors.gray}
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>
      
      <View style={styles.filterContainer}>
        <TouchableOpacity
          style={[styles.filterButton, { backgroundColor: colors.card }]}
          onPress={toggleFilter}
        >
          <Filter size={16} color={filterActive !== null ? colors.primary : colors.text} />
          <Text style={[
            styles.filterButtonText, 
            { color: filterActive !== null ? colors.primary : colors.text }
          ]}>
            {getFilterLabel()}
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.filterButton, { backgroundColor: colors.card }]}
          onPress={toggleSortBy}
        >
          <SlidersHorizontal size={16} color={colors.text} />
          <Text style={[styles.filterButtonText, { color: colors.text }]}>
            Sort by: {sortBy === 'assignmentNumber' ? 'ID' : 'Date'}
          </Text>
        </TouchableOpacity>
      </View>
      
      {loading ? (
        <View style={styles.loaderContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : filteredMembers.length > 0 ? (
        <FlatList
          data={filteredMembers}
          renderItem={renderMemberItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
        />
      ) : (
        <View style={styles.emptyContainer}>
          <UserX size={64} color={colors.grayLight} />
          <Text style={[styles.emptyTitle, { color: colors.text }]}>No members found</Text>
          <Text style={[styles.emptySubtitle, { color: colors.grayDark }]}>
            {searchQuery ? 'Try a different search term' : 'Add your first member to get started'}
          </Text>
          {!searchQuery && (
            <TouchableOpacity
              style={[styles.emptyButton, { backgroundColor: colors.primary }]}
              onPress={handleAddMember}
            >
              <Text style={styles.emptyButtonText}>Add Member</Text>
            </TouchableOpacity>
          )}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  headerTitle: {
    fontSize: 28,
    fontFamily: 'Montserrat-Bold',
  },
  addButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    borderRadius: 12,
    height: 48,
    marginBottom: 16,
  },
  searchInput: {
    flex: 1,
    height: 48,
    marginLeft: 12,
    fontFamily: 'Montserrat-Regular',
    fontSize: 16,
  },
  filterContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  filterButtonText: {
    marginLeft: 8,
    fontFamily: 'Montserrat-Medium',
    fontSize: 14,
  },
  listContainer: {
    paddingBottom: 16,
  },
  memberCard: {
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  memberHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  memberName: {
    fontSize: 18,
    fontFamily: 'Montserrat-Bold',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  statusText: {
    fontSize: 12,
    fontFamily: 'Montserrat-Medium',
  },
  memberDetails: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  memberDetailItem: {
    width: '50%',
    marginBottom: 8,
  },
  memberDetailLabel: {
    fontSize: 12,
    fontFamily: 'Montserrat-Regular',
    marginBottom: 2,
  },
  memberDetailValue: {
    fontSize: 14,
    fontFamily: 'Montserrat-Medium',
  },
  loaderContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  emptyTitle: {
    fontSize: 18,
    fontFamily: 'Montserrat-Bold',
    marginTop: 16,
  },
  emptySubtitle: {
    fontSize: 14,
    fontFamily: 'Montserrat-Regular',
    textAlign: 'center',
    marginTop: 8,
  },
  emptyButton: {
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
    marginTop: 16,
  },
  emptyButtonText: {
    fontSize: 14,
    fontFamily: 'Montserrat-Bold',
    color: '#000000',
  },
});