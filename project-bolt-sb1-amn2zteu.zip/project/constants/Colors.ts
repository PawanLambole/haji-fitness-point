export const Colors = {
  light: {
    primary: '#e0c724',
    primaryDark: '#c5af20',
    primaryLight: '#f3dc47',
    background: '#f8f9fa',
    card: '#ffffff',
    text: '#1e1e1e',
    border: '#e1e1e1',
    notification: '#ff3b30',
    error: '#dc3545',
    success: '#28a745',
    warning: '#ffc107',
    inactive: '#8e8e93',
    white: '#ffffff',
    black: '#000000',
    gray: '#8e8e93',
    grayLight: '#d1d1d6',
    grayDark: '#636366'
  },
  dark: {
    primary: '#e0c724',
    primaryDark: '#c5af20',
    primaryLight: '#f3dc47',
    background: '#1e1e1e',
    card: '#2c2c2e',
    text: '#ffffff',
    border: '#3a3a3c',
    notification: '#ff453a',
    error: '#ff453a',
    success: '#30d158',
    warning: '#ffd60a',
    inactive: '#636366',
    white: '#ffffff',
    black: '#000000',
    gray: '#8e8e93',
    grayLight: '#636366',
    grayDark: '#aeaeb2'
  }
};

export default Colors;